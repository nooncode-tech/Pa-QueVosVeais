'use client'

import { useState } from 'react'
import { Settings, Percent, Clock, CreditCard, Bell, MapPin, Save, Check, AlertTriangle, X } from 'lucide-react'
import { useApp } from '@/lib/context'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Checkbox } from '@/components/ui/checkbox'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'

const DEFAULT_METODOS_PAGO = {
  efectivo: true,
  tarjeta: true,
  transferencia: true,
}

export function ConfigManager() {
  const { config, updateConfig, emergencyCloseAllTables, emergencyCloseTables, tableSessions, orders } = useApp()
  const [showEmergencyConfirm, setShowEmergencyConfirm] = useState(false)
  const [selectedTables, setSelectedTables] = useState<number[]>([])
  
  // Ensure all config fields have defaults for backwards compatibility
  const safeConfig = {
    ...config,
    metodospagoActivos: config.metodospagoActivos || DEFAULT_METODOS_PAGO,
    sonidoNuevosPedidos: config.sonidoNuevosPedidos ?? true,
    notificacionesStockBajo: config.notificacionesStockBajo ?? true,
  }
  
  const [localConfig, setLocalConfig] = useState({ ...safeConfig })
  const [saved, setSaved] = useState(false)
  
  const handleSave = () => {
    updateConfig(localConfig)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }
  
  const hasChanges = JSON.stringify(localConfig) !== JSON.stringify(safeConfig)
  
  return (
    <div className="p-3">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-xs font-semibold text-foreground flex items-center gap-1.5">
            <Settings className="h-3.5 w-3.5" />
            Configuracion del sistema
          </h2>
          <p className="text-[10px] text-muted-foreground">
            Ajusta los parametros del restaurante
          </p>
        </div>
        <Button 
          className={`h-7 text-[10px] px-2.5 ${saved ? 'bg-success' : 'bg-primary'}`}
          onClick={handleSave}
          disabled={!hasChanges && !saved}
        >
          {saved ? (
            <>
              <Check className="h-3 w-3 mr-1" />
              Guardado
            </>
          ) : (
            <>
              <Save className="h-3 w-3 mr-1" />
              Guardar
            </>
          )}
        </Button>
      </div>
      
      <div className="space-y-3">
        {/* Taxes */}
        <Card>
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-xs flex items-center gap-1.5">
              <Percent className="h-3.5 w-3.5 text-primary" />
              Impuestos y cargos
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-[10px]">IVA (%)</Label>
                <Input
                  type="number"
                  value={localConfig.impuestoPorcentaje}
                  onChange={(e) => setLocalConfig(prev => ({ 
                    ...prev, 
                    impuestoPorcentaje: Number.parseFloat(e.target.value) || 0 
                  }))}
                  className="h-8 text-xs"
                />
              </div>
              <div>
                <Label className="text-[10px]">Propina sugerida (%)</Label>
                <Input
                  type="number"
                  value={localConfig.propinaSugeridaPorcentaje}
                  onChange={(e) => setLocalConfig(prev => ({ 
                    ...prev, 
                    propinaSugeridaPorcentaje: Number.parseFloat(e.target.value) || 0 
                  }))}
                  className="h-8 text-xs"
                />
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Session */}
        <Card>
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-xs flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-primary" />
              Sesiones de mesa
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0 space-y-3">
            <div>
              <Label className="text-[10px]">Tiempo expiracion sesion (minutos)</Label>
              <Input
                type="number"
                value={localConfig.tiempoExpiracionSesionMinutos}
                onChange={(e) => setLocalConfig(prev => ({ 
                  ...prev, 
                  tiempoExpiracionSesionMinutos: Number.parseInt(e.target.value) || 60 
                }))}
                className="h-8 text-xs"
              />
              <p className="text-[9px] text-muted-foreground mt-0.5">
                Tiempo que dura una sesion de mesa sin actividad
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Payment Methods */}
        <Card>
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-xs flex items-center gap-1.5">
              <CreditCard className="h-3.5 w-3.5 text-primary" />
              Metodos de pago
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0 space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-[10px]">Efectivo</Label>
              <Switch
                checked={localConfig.metodospagoActivos.efectivo}
                onCheckedChange={(checked) => setLocalConfig(prev => ({ 
                  ...prev, 
                  metodospagoActivos: { ...prev.metodospagoActivos, efectivo: checked }
                }))}
                className="scale-75"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-[10px]">Tarjeta</Label>
              <Switch
                checked={localConfig.metodospagoActivos.tarjeta}
                onCheckedChange={(checked) => setLocalConfig(prev => ({ 
                  ...prev, 
                  metodospagoActivos: { ...prev.metodospagoActivos, tarjeta: checked }
                }))}
                className="scale-75"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-[10px]">Transferencia</Label>
              <Switch
                checked={localConfig.metodospagoActivos.transferencia}
                onCheckedChange={(checked) => setLocalConfig(prev => ({ 
                  ...prev, 
                  metodospagoActivos: { ...prev.metodospagoActivos, transferencia: checked }
                }))}
                className="scale-75"
              />
            </div>
          </CardContent>
        </Card>
        
        {/* Delivery Zones */}
        <Card>
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-xs flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-primary" />
              Zonas de reparto
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <div className="space-y-2">
              {localConfig.zonasReparto.map((zona, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    value={zona}
                    onChange={(e) => {
                      const newZonas = [...localConfig.zonasReparto]
                      newZonas[index] = e.target.value
                      setLocalConfig(prev => ({ ...prev, zonasReparto: newZonas }))
                    }}
                    className="h-8 text-xs flex-1"
                    placeholder="Nombre de zona"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs text-destructive bg-transparent"
                    onClick={() => {
                      const newZonas = localConfig.zonasReparto.filter((_, i) => i !== index)
                      setLocalConfig(prev => ({ ...prev, zonasReparto: newZonas }))
                    }}
                  >
                    X
                  </Button>
                </div>
              ))}
              <Button
                variant="outline"
                size="sm"
                className="w-full h-8 text-xs bg-transparent"
                onClick={() => setLocalConfig(prev => ({ 
                  ...prev, 
                  zonasReparto: [...prev.zonasReparto, ''] 
                }))}
              >
                + Agregar zona
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Notifications */}
        <Card>
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-xs flex items-center gap-1.5">
              <Bell className="h-3.5 w-3.5 text-primary" />
              Notificaciones
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-[10px]">Sonido de nuevos pedidos</Label>
                <p className="text-[9px] text-muted-foreground">Reproduce sonido al recibir pedidos</p>
              </div>
              <Switch
                checked={localConfig.sonidoNuevosPedidos}
                onCheckedChange={(checked) => setLocalConfig(prev => ({ 
                  ...prev, 
                  sonidoNuevosPedidos: checked 
                }))}
                className="scale-75"
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-[10px]">Notificaciones de stock bajo</Label>
                <p className="text-[9px] text-muted-foreground">Alerta cuando un ingrediente esta bajo</p>
              </div>
              <Switch
                checked={localConfig.notificacionesStockBajo}
                onCheckedChange={(checked) => setLocalConfig(prev => ({ 
                  ...prev, 
                  notificacionesStockBajo: checked 
                }))}
                className="scale-75"
              />
            </div>
          </CardContent>
        </Card>

        {/* Emergency Close Tables */}
        <Card className="border-destructive/50">
          <CardHeader className="p-3 pb-2">
            <CardTitle className="text-xs flex items-center gap-1.5 text-destructive">
              <AlertTriangle className="h-3.5 w-3.5" />
              Cierre de emergencia
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            {(() => {
              const activeSessions = tableSessions.filter(s => s.activa)
              
              // Get order count per table
              const getTableOrderCount = (mesa: number) => {
                return orders.filter(o => o.mesa === mesa && o.status !== 'entregado' && o.status !== 'cancelado').length
              }
              
              const toggleTable = (mesa: number) => {
                setSelectedTables(prev => 
                  prev.includes(mesa) 
                    ? prev.filter(m => m !== mesa)
                    : [...prev, mesa]
                )
              }
              
              const selectAll = () => {
                setSelectedTables(activeSessions.map(s => s.mesa))
              }
              
              const clearSelection = () => {
                setSelectedTables([])
              }
              
              return (
                <>
                  <p className="text-[9px] text-muted-foreground mb-2">
                    Selecciona las mesas que deseas cerrar. Los pedidos activos asociados se eliminaran.
                  </p>
                  
                  {activeSessions.length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">
                      <AlertTriangle className="h-6 w-6 mx-auto mb-2 opacity-50" />
                      <p className="text-xs">No hay mesas activas</p>
                    </div>
                  ) : (
                    <>
                      {/* Selection controls */}
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-[10px] text-muted-foreground">
                          {selectedTables.length} de {activeSessions.length} seleccionadas
                        </p>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 text-[10px] px-2"
                            onClick={selectAll}
                          >
                            Todas
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 text-[10px] px-2"
                            onClick={clearSelection}
                            disabled={selectedTables.length === 0}
                          >
                            Ninguna
                          </Button>
                        </div>
                      </div>
                      
                      {/* Table list */}
                      <ScrollArea className="max-h-48 border border-border rounded-md mb-3">
                        <div className="p-2 space-y-1">
                          {activeSessions
                            .sort((a, b) => a.mesa - b.mesa)
                            .map(session => {
                              const orderCount = getTableOrderCount(session.mesa)
                              const isSelected = selectedTables.includes(session.mesa)
                              
                              return (
                                <div 
                                  key={session.id}
                                  className={`flex items-center gap-2 p-2 rounded-md cursor-pointer transition-colors ${
                                    isSelected 
                                      ? 'bg-destructive/10 border border-destructive/30' 
                                      : 'bg-secondary/50 hover:bg-secondary'
                                  }`}
                                  onClick={() => toggleTable(session.mesa)}
                                >
                                  <Checkbox 
                                    checked={isSelected}
                                    className="pointer-events-none"
                                  />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs font-medium text-foreground">
                                      Mesa {session.mesa}
                                    </p>
                                    <p className="text-[9px] text-muted-foreground">
                                      Total: ${session.total.toFixed(2)}
                                    </p>
                                  </div>
                                  {orderCount > 0 && (
                                    <Badge variant="outline" className="text-[9px] h-5 bg-amber-500/10 text-amber-600 border-amber-500/30">
                                      {orderCount} pedido{orderCount > 1 ? 's' : ''}
                                    </Badge>
                                  )}
                                </div>
                              )
                            })}
                        </div>
                      </ScrollArea>
                      
                      {/* Action buttons */}
                      {!showEmergencyConfirm ? (
                        <Button
                          variant="outline"
                          className="w-full h-8 text-xs border-destructive text-destructive hover:bg-destructive/10 bg-transparent"
                          onClick={() => setShowEmergencyConfirm(true)}
                          disabled={selectedTables.length === 0}
                        >
                          <AlertTriangle className="h-3 w-3 mr-1.5" />
                          Cerrar {selectedTables.length} mesa{selectedTables.length !== 1 ? 's' : ''} seleccionada{selectedTables.length !== 1 ? 's' : ''}
                        </Button>
                      ) : (
                        <div className="space-y-2">
                          <div className="p-2 bg-destructive/10 rounded-md border border-destructive/30">
                            <p className="text-[10px] text-destructive font-medium mb-1">
                              Confirmar cierre de emergencia
                            </p>
                            <p className="text-[9px] text-muted-foreground">
                              Se cerraran las mesas: {selectedTables.sort((a,b) => a-b).join(', ')}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              className="flex-1 h-8 text-xs bg-transparent"
                              onClick={() => setShowEmergencyConfirm(false)}
                            >
                              <X className="h-3 w-3 mr-1" />
                              Cancelar
                            </Button>
                            <Button
                              className="flex-1 h-8 text-xs bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                              onClick={() => {
                                emergencyCloseTables(selectedTables)
                                setSelectedTables([])
                                setShowEmergencyConfirm(false)
                              }}
                            >
                              Confirmar cierre
                            </Button>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </>
              )
            })()}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
